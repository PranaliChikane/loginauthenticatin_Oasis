'use strict';

import React from 'react-native';
import ReactNativeLogin from './App/components/App';

var {
  AppRegistry
} = React;

AppRegistry.registerComponent('ReactNativeLogin', () => ReactNativeLogin);
