// RNCookieManagerIOS.h
#import "RCTBridgeModule.h"

@interface RNCookieManagerIOS : NSObject <RCTBridgeModule>

@end